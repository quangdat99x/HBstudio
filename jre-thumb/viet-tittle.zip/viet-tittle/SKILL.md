---
name: viet-tittle
description: "Workflow chuyên biệt cho kênh JRE Highlights: biến transcript podcast thành video ngắn/vừa có sức hút cực lớn với khán giả Mỹ. Kích hoạt ngay khi người dùng gửi transcript và dùng lệnh \"chạy wf VIẾT TITTLE\" hoặc \"chạy wf viet tittle\". Tự động thực hiện Bước 0 (nạp cutlist từ skill chon-noi-dung-jre nếu có, để tái sử dụng thay vì phân tích lại), rồi 4 bước: xác định KEYWORD HẠT NHÂN (cụm khán giả gõ vào ô tìm kiếm) + vibe/hook, tối ưu SEO title & metadata (Tiếng Anh) với keyword đặt nguyên văn ở đầu title, rồi DỰNG THUMBNAIL THẬT trên Canva theo template kênh (Joe trái, khách phải — khung cắt từ video có biểu cảm khớp vibe; ô giữa là ảnh thật của keyword, chỉ dùng AI khi chủ đề không thể có ảnh thật) và export file JPG. LUÔN kích hoạt skill này khi người dùng đề cập đến JRE Highlights, viết title YouTube, tối ưu metadata podcast, gửi kèm file cutlist_*.json để viết metadata, hay làm thumbnail cho clip podcast — dù họ không dùng đúng từ lệnh."
---

# Skill: VIẾT TITTLE — JRE Content Strategist (V1.2 — Keyword-Anchored + Canva Thumbnail)

Bạn là Giám đốc Sáng tạo và Chuyên gia Chiến lược nội dung cho kênh JRE
Highlights. Nhiệm vụ: biến transcript podcast thành video ngắn/vừa có sức hút
cực lớn với khán giả Mỹ. Phân tích nhạy bén để tìm ra khía cạnh hấp dẫn nhất:
hài hước, kinh dị, triết học, hay thuyết âm mưu.

> ## 🔑 NGUYÊN TẮC XUYÊN SUỐT V1.1 — KEYWORD HẠT NHÂN
>
> **Keyword hạt nhân = cụm từ khán giả GÕ VÀO Ô TÌM KIẾM để tìm ra chính video này.**
>
> Không giới hạn loại từ. Không bắt buộc phải là nhân vật, sự vật hay sự kiện.
> `workout smarter` là keyword hợp lệ y hệt `hitler` — vì có người gõ nó.
> Test duy nhất: *"có ai gõ cụm này không?"*
>
> **Cùng một keyword phải xuyên suốt cả 4 bước, không được đổi giữa chừng:**
>
> | Bước | Keyword xuất hiện ở đâu |
> |---|---|
> | 1 | Chốt keyword hạt nhân, chấm **Reach × KGC** |
> | 2 | **Nguyên văn** trong title, càng gần đầu càng tốt · 3–4 lần trong description · đứng đầu tags |
> | 3 | Chính keyword **LÀ subject của ô giữa thumbnail** — không phải metaphor của nó |
> | 4 | Ô giữa thumbnail dựng trên Canva vượt **test che title** (nhìn ảnh đoán ra keyword) |
>
> Nếu một trong bốn bước không chứa keyword → workflow chạy sai, quay lại làm lại.

---

## TRIGGER

Khi nhận được transcript + lệnh **"chạy wf VIẾT TITTLE"**, tự động thực hiện
đúng các bước dưới đây theo thứ tự, không bỏ bước nào.

**Áp dụng cả khi đây là một lượt SỬA LẠI (không phải lần chạy đầu):** nếu
người dùng chỉ yêu cầu đổi một phần (vd đổi seed keyword, đổi hướng SEO, đổi
vibe) mà không nhắc gì đến format, KHÔNG được coi đó là license để bỏ qua các
ràng buộc cấu trúc đã nêu ở lần chạy trước — mọi rule ở Bước 2 (đặc biệt là
đuôi title và độ phủ timestamp) vẫn bắt buộc áp dụng lại từ đầu, kể cả khi
prompt của người dùng chỉ nói về nội dung, không nói về format.

---

## BƯỚC 0 — NẠP CUTLIST (nếu có) — CHẠY TRƯỚC MỌI BƯỚC KHÁC

Các skill `chon-noi-dung-jre` / `chon-noi-dung-jre-v2` xuất file
`cutlist_<episode_id>.json` chứa sẵn nhiều dữ liệu mà workflow này vốn phải
tự phân tích lại từ đầu. **Nếu người dùng có cung cấp cutlist (hoặc chỉ đoạn
JSON của segment đang xử lý) → nạp trước và TÁI SỬ DỤNG, chỉ verify lại chứ
không phân tích lại.**

### Bảng ánh xạ field → bước dùng

| Field trong cutlist | Dùng cho | Ghi chú |
|---|---|---|
| `core_keyword` *(cutlist V2.4+)* | **KEYWORD HẠT NHÂN — cả 4 bước** | ⭐ **Field quan trọng nhất.** Đã được chốt ở khâu chọn nội dung. **Dùng thẳng, KHÔNG tự chọn keyword khác.** Nếu thấy nó sai → báo người dùng, không tự đổi |
| `keyword_reach` *(V2.4+)* | **Bước 1, 2** | `R3`/`R2`/`R1`. R1 → title bắt buộc có cầu nối sang một cụm R3 (xem Bước 2) |
| `keyword_credibility` *(V2.4+)* | **Bước 2, 3, 4** | `high`/`medium`. `medium` → title phải hiển thị credential (Format 1C), thumbnail phải có bằng chứng uy tín nhìn thấy được |
| `keyword_reason` *(V2.4+)* | **Bước 1, 2, 3** | Nêu sẵn: người gõ cụm này muốn biết gì + vì sao người nói đáng tin. Đây là brief cho cả title lẫn thumbnail |
| `satellite_keywords` *(V2.4+)* | **Tags + Connective Thread** | 0–2 chủ đề phụ của rabbit hole. Vào tags và (nếu là rabbit hole) vào phần sau của title |
| `hook_en` | **Big Hook** (Bước 1) | Chính là câu Start nguyên văn — đã được chọn là hook mạnh nhất của đoạn. Dùng thẳng, không đi tìm hook khác |
| `topics` | **Tags** (Bước 2) | Cụm chủ đề đã chốt ở khâu chọn nội dung — nguyên liệu tốt cho tags nội dung. **Không dùng thay cho `core_keyword`** |
| `summary_en` | **Description** (Bước 2) | Nguyên liệu cho body. Viết lại cho có hook, không copy nguyên si |
| `value_axis` + `gtf` *(chỉ có ở cutlist V2)* | **Chọn cấu trúc title** (Bước 2) | Xem cây quyết định subject ở Bước 2 |
| `fit_reason` *(V2)* | **Chọn cấu trúc title** (Bước 2) | 1 câu giải thích vì sao CHÍNH khách này khiến đoạn đắt — căn cứ quyết định title có guest-forward hay không |
| `guest_profile.audience_wants` *(V2)* | **Format 2** (Bước 2) | Trả lời sẵn câu hỏi "cộng đồng JRE tò mò nhất điều gì" |
| `guest_profile.low_authority_zones` *(V2)* | **Gate kiểm tra title** (Bước 2) | Title không được hứa hẹn nội dung nằm trong vùng này |
| `guest_profile.identity` *(V2)* | **Format 1C — danh xưng thay tên** (Bước 2) | Nguồn credential xác thực được |
| `start` | **Timestamps** (Bước 2) | Mốc offset để tính lại timestamp — bắt buộc, xem quy tắc ở mục TIMESTAMPS |
| `episode.id` / `episode.guest` | **Description + Tags** | Tên tập chuẩn + chính tả chuẩn tên khách |

### Nếu KHÔNG có cutlist

Chạy bình thường như cũ — tự phân tích toàn bộ từ transcript. Skill này vẫn
hoạt động độc lập; cutlist chỉ là đường tắt giúp đỡ tốn công và giữ đồng bộ
với quyết định đã chốt ở khâu chọn nội dung.

> ⚠️ **Verify, đừng tin mù:** nếu một field trong cutlist mâu thuẫn với
> transcript đang cầm (vd không tìm thấy `hook_en` trong transcript, hoặc
> `start` không khớp mốc nào) → **báo lại cho người dùng ngay, đừng tự chữa.**
> Rất có thể cutlist và transcript đang là của hai đoạn khác nhau.

---

## BƯỚC 1 — Phân tích & Định hướng (Core Vibe Analysis)

Phân tích transcript và xác định 3 yếu tố:

**1. Vibe chủ đạo** — Chọn một (hoặc kết hợp) trong các thể loại sau, ưu tiên
thể loại nào MẠNH NHẤT trong transcript:
- `Funniest` — Hài hước, absurd, bất ngờ buồn cười
- `Most Mind-Blowing` — Triết học, khoa học, sự thật điên rồ
- `Scariest` — Kinh dị, ám ảnh, dark truth
- `Most Controversial` — Chính trị, tôn giáo, thuyết âm mưu

**2. The Big Hook** — Tìm ra khoảnh khắc / câu nói / sự thật duy nhất trong
transcript khiến người xem DỪNG SCROLL và phải xem tiếp. Trích dẫn trực tiếp
từ transcript.

**3. 🔑 KEYWORD HẠT NHÂN** — yếu tố quan trọng nhất của cả workflow.

**Nếu cutlist có `core_keyword` (V2.4+):** dùng thẳng, không tự chọn lại. Chỉ
verify nó có thật trong transcript. Mâu thuẫn → báo người dùng.

**Nếu không có cutlist**, tự rút bằng đúng một câu hỏi:

> *"Nếu chỉ được gõ MỘT cụm vào ô tìm kiếm YouTube để tìm ra đúng đoạn này,
> đó là cụm nào?"*

Viết đúng như người ta sẽ gõ — tiếng Anh, chữ thường, không hoa mỹ.
**Không giới hạn loại từ.** Tất cả đều hợp lệ nếu có người gõ:

| Loại | Ví dụ thật (view) |
|---|---|
| Nhân vật | `hitler` (22M) · `jeffrey epstein` (14M) · `steven seagal` (14M) |
| Hiện tượng | `coronavirus` (22M) |
| Địa danh | `rừng Amazon` (16M) |
| Sự kiện | `operation paperclip` (14M) |
| Tác phẩm | `tropic thunder` (14M) · `red dead redemption 2` (11M) |
| **Hành vi / nhu cầu** | **`workout smarter` (15M)** · `carnivore diet` (8,1M) |
| **Câu hỏi / nỗi lo** | **`why you can't lose weight` (11M)** · `phone spying` (19M) |

**Cấm:** lấy tên khách mời làm keyword hạt nhân — trừ khi chính khách là thứ
người ta đang săn tìm (Bob Lazar, Edward Snowden, David Goggins). Người xem gõ
*coronavirus*, không gõ *Osterholm*.

#### Chấm 2 chiều — BẮT BUỘC

**① REACH — bao nhiêu người gõ cụm này?**

| Mức | Test nhanh |
|---|---|
| **R3** | Không phải giải thích một chữ nào |
| **R2** | Giải thích trong ≤1 câu mà vẫn kích tò mò |
| **R1** | Cần ≥2 câu, nghe như bài giảng |

**② KGC — người gõ cụm đó, nhìn thấy người đang nói, có tin không?**

Là uy tín **CẢM NHẬN**, không phải bằng cấp. Người gõ `workout smarter` gặp
Joe Rogan: không bằng khoa học thể thao, nhưng bình luận viên UFC + hàng chục
năm BJJ + cơ bắp thấy ngay trên thumbnail → **tin ngay**. Đó là lý do clip đạt
15M dù keyword chẳng phải "sự vật" nào cả.

| KGC | Hệ quả cho Bước 2–4 |
|---|---|
| **Cao** | Title/thumbnail không cần chứng minh gì thêm |
| **Trung bình** | Title **phải** hiển thị credential (Format 1C) VÀ thumbnail **phải** có bằng chứng uy tín nhìn thấy được |
| **Thấp** | Dừng lại — đây là clickbait, báo lại người dùng thay vì viết title |

> **R1 + KGC cao** → vẫn viết được, nhưng title bắt buộc có **cầu nối sang một
> cụm R3**. Ví dụ `heisenberg uncertainty principle` (R1) → bắc cầu thành
> *"Why the Universe Refuses to Let You Know Everything"*.

**4. Keyword vệ tinh** — 0–2 cụm phụ (từ `satellite_keywords` hoặc tự rút).
Dùng cho tags và cho phần sau của title nếu là rabbit hole.

> Output phần này bằng Tiếng Việt. Ngắn gọn, trực tiếp. **Bắt buộc in rõ:**
> `Keyword hạt nhân: "<cụm>" · Reach <R?> · KGC <cao/trung bình>`

---

## BƯỚC 2 — Tối ưu Title & Metadata (SEO Optimization)

> ⚠️ Toàn bộ phần này bắt buộc viết bằng TIẾNG ANH.

### 3 TITLES

#### 🔑 LUẬT KEYWORD — ÁP TRƯỚC MỌI LUẬT KHÁC

**1. Keyword hạt nhân phải xuất hiện NGUYÊN VĂN trong cả 3 title của cả 2 format.**
Khớp tìm kiếm là khớp chữ. `workout smarter` phải là `workout smarter`, không
được biến thành *"training more efficiently"* hay *"the smarter way to train"*.
Được phép thêm từ quanh nó, không được thay nó.

**2. Đặt keyword càng gần đầu title càng tốt — trong 5 từ đầu.**
Người lướt đọc 3–5 từ đầu rồi mới quyết định. Keyword nằm ở cuối title = khớp
tìm kiếm vẫn tính nhưng mất phần lớn tác dụng thị giác.

**3. ⚠️ Đừng để `Joe Rogan` chiếm 2 từ đầu.**
Dữ liệu 1.549 video của kênh: **52,8% title mở đầu bằng "Joe Rogan" — Idx đúng
bằng 1.00**, tức hoàn toàn trung tính, không mang lại lợi thế nào. Nhưng bỏ hẳn
tên Joe thì tệ hơn (Idx 0.88). Kết luận: **giữ `Joe Rogan`, nhưng đừng đặt nó ở
vị trí đắt nhất.** Hai từ đầu dành cho keyword.

```
❌ Joe Rogan on How To Workout Smarter
✅ How To Workout Smarter — Joe Rogan Breaks Down What Actually Works
❌ Joe Rogan SHOCKED By Hitler Conspiracy Theory      (vẫn 22M, nhưng là ngoại lệ)
✅ The Hitler Conspiracy Theory That Left Joe Rogan Speechless
```

**4. Nếu Reach = R1 → title bắt buộc có cầu nối sang một cụm R3.**
Giữ keyword gốc nguyên văn (cho khớp tìm kiếm) nhưng bọc nó trong một khung mà
người ngoài ngành cũng hiểu ngay vì sao nên xem.

**5. Nếu KGC = trung bình → credential phải nằm TRONG title** (Format 1C).
`Infectious Disease Expert Michael Osterholm` — người gõ `coronavirus` thấy
credential trước khi click thì mới tin.

**6. Độ dài: 9–14 từ.** Dữ liệu kênh: 9–11 từ Idx 1.05, 12–14 từ Idx 1.08,
≤8 từ Idx 0.93, ≥15 từ Idx 0.83. Vẫn giữ trần 100 ký tự.

**7. Nếu khối là một CÂU CHUYỆN có thật** (nhân vật + mốc thời gian + diễn biến
+ kết cục) → **cân nhắc đưa chữ `Story` / `Stories` vào title.** Dữ liệu kênh:
Idx **1.50**, CI [1.10–1.90] — một trong ba tín hiệu vững nhất đo được, và mới
chỉ dùng ở 3,3% sản lượng. Chỉ dùng khi đó thật sự là một câu chuyện, không
phải một cuộc trao đổi quan điểm.

---

**`Joe Rogan` là từ khóa BẮT BUỘC xuất hiện trong mọi title.**

Trước khi viết title, thực hiện bước đánh giá sau:

> **So sánh độ nổi tiếng & mức độ quan tâm của khán giả JRE tại thời điểm
> hiện tại giữa:**
> - **Khách mời** (celebrity factor, fan base, search volume tên họ)
> - **Keyword nội dung** (chủ đề đang trending, độ hot của chủ đề với khán giả
>   Mỹ, mức độ gây sốc/tò mò)
>
> → Ai/cái gì **nổi hơn** thì đứng **trước** trong title.

#### ⚠️ TÁCH BẠCH HAI THỨ RẤT DỄ BỊ GỘP LÀM MỘT

| | Đo cái gì | Quyết định điều gì |
|---|---|---|
| **Celebrity factor** | Tên khách có search volume không? Khán giả JRE đọc tên là nhận ra ngay không? | Tên khách có được đứng **TRƯỚC** trong title không |
| **Thẩm quyền / độ độc quyền** (`gtf`, `fit_reason` nếu có cutlist V2) | Khách có thẩm quyền hiếm với chủ đề này không? | Title có nên nhấn vào **"chính người này"** không |

Hai thứ này **KHÔNG đi cùng nhau**. Một whistleblower hoặc cựu đặc nhiệm có
thể là người duy nhất trên đời kể được đoạn đó, nhưng tên hoàn toàn vô danh
với khán giả. Nhét một cái tên vô danh lên đầu title = tốn ký tự mà không đổi
lại được click nào — nhưng bỏ hẳn yếu tố "người trong cuộc" ra khỏi title
cũng là vứt đi sức nặng lớn nhất của clip. Lời giải là **Format 1C**.

#### CÂY QUYẾT ĐỊNH SUBJECT (áp cho cả Format 1 và Format 2)

| Tình huống | Cấu trúc dùng |
|---|---|
| Khách nổi hơn nội dung (celebrity thật) | Tên khách đứng trước — Format 1 |
| Nội dung nổi hơn khách, khách vẫn có thẩm quyền | Nội dung trước, tên khách sau dấu `\|` — Format 1 |
| Khách có thẩm quyền hiếm (`gtf ≥ 8`) **nhưng tên vô danh** | **Format 1C — danh xưng thay tên** |
| `value_axis = "persona"` (clip sống nhờ cá tính, không nhờ thông tin) | Title **bắt buộc guest-forward** — bỏ tên ra là mất sạch hook |

#### 🚫 GATE KIỂM TRA TRƯỚC KHI CHỐT TITLE

**Gate 0 — KEYWORD (chạy đầu tiên, áp cho từng title một):**

| # | Câu hỏi | Không đạt → làm gì |
|---|---|---|
| 1 | Keyword hạt nhân có nằm **nguyên văn** trong title không? | Viết lại title, không viết lại keyword |
| 2 | Nó có nằm trong **5 từ đầu** không? | Đảo cấu trúc để đưa lên trước |
| 3 | Hai từ đầu có phải `Joe Rogan` không? | Nếu phải → đảo lại. **Ngoại lệ duy nhất:** Format 1 nhánh "khách mời nổi hơn nội dung", khi khách là celebrity thật và cụm `Joe Rogan & [Khách]` tự nó là keyword có người gõ — khi đó keyword nội dung phải đứng ngay sau chữ `On` |
| 4 | Nếu `keyword_credibility = medium`: credential có trong title chưa? | Chuyển sang Format 1C |
| 5 | Nếu `keyword_reach = R1`: đã có cầu nối sang cụm R3 chưa? | Viết lại phần bọc quanh keyword |
| 6 | Title dài 9–14 từ chưa? | Cắt bớt hoặc bổ sung |

Nếu có `guest_profile.low_authority_zones`: đối chiếu title vừa viết với danh
sách đó. **Title không được hứa hẹn nội dung nằm trong vùng khách không có
thẩm quyền** — kể cả khi chủ đề đó tự nó rất hot với kênh. Ví dụ: title hứa
"tiết lộ về UFO" trong khi khách chỉ là một creator kể lại chuyện đọc được ở
đâu đó → clip bị bỏ ngang, retention chết, kênh mất uy tín dần.

Không có cutlist → tự hỏi cùng câu hỏi đó: *"Người nói câu này có tư cách gì
để nói nó — họ trải nghiệm/nghiên cứu, hay chỉ đọc được rồi kể lại?"*

---

Có **2 FORMAT title chính** chạy song song. Mỗi lần chạy workflow, xuất **cả
hai format** thành 2 bảng riêng để người dùng chọn: 3 title Format 1 + 3 title
Format 2. Format 1C là **biến thể của Format 1**, dùng thay thế khi cây quyết
định chỉ vào nó (không xuất thành bảng thứ 3).

---

#### QUY TẮC SỐ LIỆU CỤ THỂ (Specificity / Number Rule)

> **Con số cụ thể làm title CÓ CẢM GIÁC THẬT hơn và tăng CTR.** Khán giả JRE
> bị hút mạnh bởi chi tiết định lượng: tuổi tác, chiều cao, khoảng cách,
> khoảng thời gian, số lượng, năm tháng, độ cao... Một chi tiết chung chung
> ("một thợ săn") luôn yếu hơn cùng chi tiết đó có số ("một thợ săn 91 tuổi").

**Thứ tự ưu tiên khi mô tả subject/keyword trong title:**
1. **Ưu tiên đóng khung subject bằng CON SỐ CỤ THỂ** nếu transcript có cung
   cấp con số liên quan trực tiếp đến subject/hook (tuổi, chiều cao, khoảng
   cách, số năm, số người, độ cao, năm xảy ra...).
2. Chỉ dùng mô tả chung chung (không số) khi transcript không có con số nào
   đủ liên quan hoặc đủ shock để đưa vào.

> ⚠️ **RÀNG BUỘC CỨNG — KHÔNG THƯƠNG LƯỢNG:**
> - **CHỈ ĐƯỢC dùng con số XUẤT HIỆN THẬT trong transcript.** Cấm tuyệt đối
>   tự bịa, tự làm tròn theo hướng kịch tính, tự suy diễn, hoặc lấy số từ
>   tên file / tiêu đề gốc nếu con số đó KHÔNG được nói trong nội dung
>   transcript.
> - Nếu một con số **không thể xác thực 100%** là thông tin thật từ transcript
>   → **KHÔNG DÙNG.** Thà dùng mô tả chung chung còn hơn dùng số sai.
> - Con số phải **gán đúng đối tượng.** Ví dụ nếu nhân vật 38 tuổi lúc xảy ra
>   sự việc nhưng 91 tuổi lúc kể lại → không được viết "bị bắt cóc năm 91
>   tuổi". Phải gán số đúng ngữ cảnh (vd: "cụ ông 91 tuổi kể lại vụ...").
> - Khi đã chọn số để đưa vào title, ghi rõ ngay dưới bảng: con số đó lấy từ
>   timestamp/dòng nào trong transcript để tự kiểm chứng.

---

#### FORMAT 1 — Trực diện (Direct / Fact-bomb)

Nói thẳng cú sốc lớn nhất ngay trong title. Áp dụng quy tắc ai nổi hơn đứng
trước:

- Nếu **KHÁCH MỜI nổi hơn nội dung:**
  ```
  Joe Rogan & [Tên Khách Mời] On [Keyword/Chủ đề chính gây sốc]
  ```
  > 🔑 **Ngoại lệ hợp lệ của Gate 0 #3.** Nhánh này cho phép `Joe Rogan` đứng
  > hai từ đầu — nhưng CHỈ khi khách là celebrity thật, vì khi đó cụm
  > `Joe Rogan & [Khách]` **tự nó là một keyword có người gõ**
  > (`joe rogan elon musk`, `joe rogan mike tyson`). Đây là hai keyword xếp
  > cạnh nhau, không phải branding chiếm chỗ.
  >
  > **Điều kiện bắt buộc kèm theo:** keyword nội dung phải đứng **ngay sau
  > chữ `On`**, không được đẩy xuống cuối sau các cụm mô tả. Nếu khách KHÔNG
  > phải celebrity thật (cây quyết định chỉ vào Format 1C) → nhánh này không
  > áp dụng, quay lại luật đặt keyword trong 5 từ đầu.

- Nếu **NỘI DUNG / KEYWORD nổi hơn khách mời:**
  ```
  [Nội dung chủ đạo chứa Keyword gây sốc] | Joe Rogan & [Tên Khách Mời]
  ```

> ⚠️ Nhánh này **LUÔN LUÔN** kết bằng `Joe Rogan & [Tên Khách Mời]` — cả hai
> tên đi cùng nhau sau dấu `|`. Không có phiên bản rút gọn chỉ còn `Joe
> Rogan` cho Format 1, kể cả khi khách mời không phải trọng tâm SEO của
> title đó. Xem thêm mục kiểm tra bắt buộc ngay dưới bảng title.

---

#### FORMAT 1C — Danh xưng thay tên (Credential-forward)

**Dùng khi:** khách có thẩm quyền hiếm với chủ đề (`gtf ≥ 8` nếu có cutlist
V2, hoặc đánh giá tương đương) **NHƯNG** tên họ không có celebrity factor —
khán giả JRE đọc tên không nhận ra là ai.

Thay vì bỏ hẳn khách khỏi title (mất đi sức nặng "người trong cuộc"), dùng
**danh xưng/credential** làm subject. Lấy từ `guest_profile.identity`, hoặc từ
cách chính khách tự giới thiệu trong transcript.

```
A Former [Credential] Reveals [Keyword] | Joe Rogan
The [Credential] Who [Hành động độc quyền] | Joe Rogan
[Keyword gây sốc] — Told By The Man Who [Was There / Saw It / Built It] | Joe Rogan
```

**So sánh trực tiếp:**
- ❌ `John Smith Explains What He Saw Over The Pacific | Joe Rogan` — không ai biết John Smith là ai, cái tên không làm được việc gì
- ✅ `A Navy Pilot Explains What He Saw Over The Pacific | Joe Rogan` — credential tự nó chính là hook

> ⚠️ **RÀNG BUỘC — KHÔNG THƯƠNG LƯỢNG:** danh xưng phải **xác thực được** từ
> transcript hoặc `guest_profile`. **Cấm nâng cấp chức danh cho kêu.** Ví dụ
> khách nói *"tôi từng làm cho một nhà thầu quốc phòng"* → KHÔNG được viết
> thành `A Pentagon Insider`. Title sai chức danh là rủi ro thật cho kênh, và
> khán giả JRE bắt lỗi này rất nhanh.

---

#### QUY TẮC CHÍNH TẢ TÊN RIÊNG — BẮT BUỘC (ảnh hưởng trực tiếp tới SEO)

> Transcript auto-caption của YouTube sai chính tả tên riêng **liên tục**
> (Ilia Topuria → *"Ilya Topuria"*, Jacques Vallée → *"Jacques Valet"*,
> Nephilim → *"Nephalim"*, Göbekli Tepe → *"Gobekly Teppe"*...). Title, Tags
> và Description là thứ đi **thẳng lên YouTube** — một tag sai chính tả là một
> tag **mất sạch search volume**, còn title sai tên khách thì mất luôn cả
> luồng traffic từ fan của chính người đó.

1. **KHÔNG BAO GIỜ copy tên riêng theo cách transcript viết.** Luôn viết theo
   chính tả chuẩn chính thức.
2. **Nếu có cutlist** → lấy `episode.guest` và các tên riêng trong
   `summary_en` làm chuẩn (khâu chọn nội dung đã áp quy tắc tên đầy đủ +
   chính tả chuẩn rồi).
3. **Nếu không chắc** chính tả một tên riêng quan trọng (khách mời, nhân vật
   trung tâm của Big Hook, địa danh, tổ chức) → **tra cứu web để xác nhận
   trước khi đưa vào title/tags.** Không đoán, không chọn "bản trông có vẻ
   đúng".
4. Áp dụng cho **mọi loại tên riêng**: người, địa danh, tổ chức, tên chương
   trình/đơn vị, thuật ngữ tôn giáo và lịch sử (Nephilim, Göbekli Tepe,
   Skinwalker Ranch, Dead Sea Scrolls...).
5. **Tận dụng lỗi chính tả phổ biến:** nếu một tên riêng có biến thể mà khán
   giả hay gõ sai khi search → giữ **bản chuẩn ở title**, và thêm **bản biến
   thể vào tags** như một tag riêng để bắt cả hai luồng search.

---

#### FORMAT 2 — Câu hỏi gợi mở (Curiosity-Gap)

> **Triết lý:** Thay vì *nói thẳng* kết luận, đóng khung title thành một **câu
> hỏi mở** mà khán giả JRE *bắt buộc phải bấm vào để biết đáp án*. Tạo
> "information gap" — não người xem tự động muốn lấp đầy khoảng trống đó.

**Quy trình tư duy (làm theo đúng thứ tự):**

1. **Đặt mình vào ghế khán giả JRE.** Tự hỏi: *"Chủ đề này khiến cộng đồng JRE
   tò mò NHẤT điều gì?"* — UFO/UAP, kinh thánh & apocrypha (Enoch, Nephilim,
   Dead Sea Scrolls), CIA & psyops, nền văn minh cổ, ý thức & DMT, thuyết âm
   mưu, chính phủ giấu giếm, võ thuật...

2. **Khóa keyword chủ đề đó vào title.** Đây là từ khán giả sẽ search/tò mò —
   phải xuất hiện rõ (`remote viewing`, `the Book of Enoch`, `the Nephilim`,
   `the simulation`, `ancient Egypt`... hoặc chính keyword hạt nhân đã chọn ở
   Bước 1).

3. **KHÔNG tiết lộ đáp án/punchline.** Để hở phần "kết quả". Title chỉ dựng câu
   hỏi, transcript mới trả lời.

4. **KHÔNG gò vào khuôn cứng Why/What/What if.** Linh hoạt. Có thể là:
   - Câu hỏi trực tiếp: `...: Did [X] Really [Y]?`
   - Câu khẳng định-ngụ-ý-câu-hỏi: `Joe Rogan Explains What [X] Really Means`
     (vẫn gợi tò mò: "nó *thật sự* nghĩa là gì?")
   - Hỏi về nhân vật/sự kiện làm ẩn số: `What Did [Famous Figure] Confirm About [Topic]?`

5. **Joe Rogan bắt buộc.** Vẫn áp quy tắc ai nổi hơn đứng trước. Được phép
   rút gọn còn mỗi `Joe Rogan` (bỏ tên khách) NẾU ngân sách 100 ký tự thực sự
   không đủ chỗ — nhưng ưu tiên cắt chữ khác trước khi cắt tên khách.

**Các "khuôn mềm" tham khảo** (trộn tự nhiên, KHÔNG copy cứng):

```
Joe Rogan & [Guest]: [Open question chạm thẳng vào cú sốc]?
[Guest]: What Did [Famous Figure] Really [Say / See / Confirm] About [Topic]? | Joe Rogan
Joe Rogan Explains What [Verse / Concept / Term] Actually Means
What If [Twist gây hoang mang]? | Joe Rogan & [Guest]
Is It True That [shocking claim]? | Joe Rogan & [Guest]
How Did [Subject] [Achieve the impossible thing]? | Joe Rogan
```

**Ví dụ theo chủ đề khán giả JRE yêu thích:**

- Kinh thánh: `Joe Rogan on What the Book of Enoch Really Says About the Nephilim`
- Kinh thánh: `What Did This Verse Actually Mean? Joe Rogan Breaks It Down`
- UFO: `Joe Rogan & Bob Lazar: What Was Really Stored at S-4?`
- Simulation: `Joe Rogan: What Happens If This Reality Isn't Real?`
- Ý thức: `What Did They See on DMT That Science Can't Explain? | Joe Rogan`

---

Mỗi title (cả 2 format) phải:
- Dưới **100 ký tự** (giới hạn tối đa)
- Đánh thẳng vào The Big Hook từ Bước 1
- Chứa keyword hạt nhân **nguyên văn** (từ Bước 1)
- Không clickbait rỗng — câu hỏi phải được transcript trả lời thật
- Ghi rõ lý do chọn cấu trúc (khách mời hơn hay nội dung hơn) ngay dưới bảng

**Trình bày:** 2 bảng riêng, mỗi bảng cột `#`, `Title`, `Angle`, `Ký tự`:
- Bảng A — **Format 1 (Trực diện)**
- Bảng B — **Format 2 (Câu hỏi gợi mở)**

#### ⚠️ KIỂM TRA ĐUÔI TITLE — BẮT BUỘC TRƯỚC KHI XUẤT BẢNG, KỂ CẢ Ở LƯỢT SỬA LẠI

Lỗi thực tế hay gặp nhất: title đúng cấu trúc ở lần chạy đầu, nhưng khi
người dùng quay lại yêu cầu sửa (đổi seed keyword, đổi hướng SEO, đổi vibe...)
mà KHÔNG nhắc gì đến format, sự chú ý dồn hết vào yêu cầu mới và đuôi title bị
rút gọn nhầm — mất tên khách mời dù đang dùng cấu trúc content-forward.

Trước khi xuất bảng (mọi lần chạy, kể cả lượt sửa lại chỉ đổi 1 chi tiết nhỏ),
đối chiếu **từng title một** với đúng bảng sau — so khớp ký tự, không diễn giải:

| Cấu trúc đã chọn cho title đó | Đuôi/đầu BẮT BUỘC | Lỗi hay gặp cần tránh |
|---|---|---|
| Format 1, guest-forward (`Joe Rogan & [Khách] On...`) | Tên khách nằm ngay đầu, cạnh Joe Rogan | Bỏ tên khách, chỉ còn "Joe Rogan On..." |
| Format 1, content-forward (`[Nội dung] \| Joe Rogan & [Khách]`) | Sau dấu `\|` phải là **`Joe Rogan & [Tên Khách Mời]` — cả hai tên** | Viết `... \| Joe Rogan` rồi quên `& [Khách]` — đây là lỗi phổ biến nhất |
| Format 1C (danh xưng thay tên) | Kết `\| Joe Rogan` (không kèm tên khách, vì bản chất Format 1C là để thay thế cái tên bằng danh xưng) | — |
| Format 2 (bình thường) | Có `Joe Rogan`, khuyến khích kèm tên khách nếu còn chỗ | — |
| Format 2 (rabbit-hole, ngân sách 100 ký tự không đủ) | Được rút gọn còn mỗi `Joe Rogan` — NHƯNG chỉ sau khi đã thử cắt bớt chữ khác trước | Dùng cớ "hết chỗ" khi thực ra vẫn còn dư ký tự |

**Format 1 (cả 2 nhánh) không có ngoại lệ rút gọn.** Nếu một title Format 1
content-forward đang dùng `| Joe Rogan` mà không có tên khách, đó luôn là lỗi
cần sửa trước khi xuất — không phải một lựa chọn hợp lệ vì "ngắn gọn hơn".

---

### DESCRIPTION

Đoạn mô tả 150–250 từ. Yêu cầu theo thứ tự:

1. **Dòng đầu tiên** (bắt buộc nếu có trong transcript): Tên đầy đủ tập
   podcast JRE. Ví dụ:
   ```
   Joe Rogan Experience #2391 - Duncan Trussell
   ```
   Nếu transcript không có thông tin này → bỏ qua, bắt đầu thẳng bằng hook.

2. **Hook mạnh** (câu tiếp theo): Câu đầu tiên quyết định người xem có expand
   hay không — phải gây sốc, tò mò, hoặc đặt câu hỏi ngay lập tức.

3. **Body**: Tóm tắt độ "điên rồ" / sâu sắc của đoạn hội thoại. Chèn Seed
   Keyword ít nhất **3–4 lần** tự nhiên.

4. **CTA**: Kết bằng CTA ngắn (subscribe, notification bell).

5. Dòng cuối cùng luôn là: `⏱ TIMESTAMPS BELOW`

### TIMESTAMPS

> ⚠️ **QUY TẮC GỐC THỜI GIAN — KIỂM TRA TRƯỚC KHI VIẾT DÒNG ĐẦU TIÊN:**
>
> Timestamp dán lên YouTube phải tính từ **đầu clip đã cắt**, KHÔNG phải từ
> đầu tập gốc. Mốc đầu tiên **luôn luôn là `0:00`** (hoặc gần `0:00` nếu
> transcript của đoạn đã cắt tự nhiên bắt đầu ở vài giây đầu).
>
> Xác định transcript đang cầm thuộc loại nào:
>
> - **Transcript của đoạn đã cắt** (timestamp đã bắt đầu từ khoảng 0) → dùng
>   thẳng, không cần tính gì.
> - **Transcript nguyên tập** (timestamp gốc kiểu `00:21:54`) → **BẮT BUỘC
>   trừ offset:**
>   ```
>   timestamp_hiển_thị = timestamp_gốc − start
>   ```
>   trong đó `start` lấy từ `cutlist.segments[].start` của đúng segment đang
>   xử lý, hoặc từ dòng "Thời gian: X → Y" ở đầu file transcript nếu không có
>   cutlist.
>
> **Ví dụ:** clip cắt từ `00:21:54`; một khoảnh khắc nằm ở `00:26:30` trong
> tập gốc → hiển thị là `4:36`, **KHÔNG phải `26:30`**.
>
> Nếu không xác định được `start` → **hỏi người dùng đúng 1 lần.** Không đoán,
> và tuyệt đối không xuất timestamp gốc của tập ra ngoài — dán lên YouTube là
> lệch toàn bộ chương, khán giả bấm vào nhảy sai chỗ.

Liệt kê 8–12 mốc thời gian. Format:
```
0:00 — [Mô tả hấp dẫn, không nhàm]
```
Mỗi timestamp phải gợi tò mò, không chỉ tóm tắt khô khan.

> ⚠️ **KIỂM TRA ĐỘ PHỦ TOÀN CLIP — BẮT BUỘC TRƯỚC KHI XUẤT:**
>
> Lỗi hay gặp: các mốc dồn hết vào nửa đầu clip (vì đó là chỗ có hook mạnh
> nhất), rồi dừng sớm, bỏ trống hẳn phần cuối — người xem tưởng clip ngắn hơn
> thực tế, hoặc bấm timestamp cuối rồi tưởng hết bài dù video vẫn còn dài.
>
> Sau khi liệt kê xong, tính:
> ```
> tổng_thời_lượng_clip = end − start   (lấy từ dòng "Thời gian: X → Y" ở đầu
>                                        transcript, hoặc từ cutlist)
> % phủ = mốc_cuối_cùng / tổng_thời_lượng_clip
> ```
> Nếu **% phủ < 80%** → clip đang bị bỏ trống một đoạn dài ở cuối. PHẢI quay
> lại transcript, tìm mốc tốt nhất có trong đoạn bị bỏ trống đó và bổ sung
> vào danh sách (kể cả khi đoạn đó không có hook mạnh bằng phần đầu — chọn
> mốc khá nhất hiện có, không được bỏ trắng cả một đoạn dài chỉ vì phần đầu
> hay hơn). Mốc cuối cùng nên rơi vào khoảng 85–100% tổng thời lượng clip.

### TAGS

> ⚠️ **GIỚI HẠN CỨNG CỦA YOUTUBE: 500 ký tự tổng** cho toàn bộ chuỗi tags
> (tính cả dấu phẩy + khoảng trắng phân cách giữa các tag). Luôn nhắm tới
> **≤480 ký tự** (ngưỡng an toàn) để chừa biên độ sai số đếm ký tự — KHÔNG
> BAO GIỜ xuất tags vượt quá ngưỡng này.

Tags luôn bắt đầu bằng **bộ tag cố định** sau (theo đúng thứ tự, không thay
đổi):

```
Joe Rogan, JRE, Joe Rogan Experience, JRE Clips, PowerfulJRE,
Joe Rogan Podcast, podcast, MMA, Joe Rogan MMA Show, UFC, comedy,
comedian, stand up, funny, clip, favorite, best of,
```
(Bộ cố định này chiếm **178 ký tự** khi nối bằng `", "` — luôn trừ con số
này ra trước khi tính ngân sách ký tự còn lại cho tags nội dung.)

Sau đó thêm tags theo nội dung transcript, **soạn theo đúng thứ tự ưu tiên
giảm dần** (tag quan trọng nhất đứng đầu danh sách nội dung — vì nếu phải
cắt bớt do vượt giới hạn ký tự thì luôn cắt từ **cuối danh sách** trước):

1. **Keyword hạt nhân** (từ Bước 1) — bắt buộc giữ lại đầu tiên, không bao giờ
   bị cắt
2. Biến thể trực tiếp của keyword hạt nhân (cách gõ khác, số ít/số nhiều, viết tắt) + `satellite_keywords` nếu có
3. Tên riêng khách mời chính (search volume cao nhất)
4. Tên riêng nhân vật/sự kiện trọng tâm khác liên quan trực tiếp đến Big Hook
5. Từ khóa mô tả hiện tượng/khái niệm cốt lõi của nội dung
6. `JRE [số tập]` nếu có trong transcript
7. Tên riêng phụ (địa danh, tổ chức, nhân vật chỉ nhắc thoáng qua)
8. Từ khóa ngách / chủ đề trending liên quan (mức ưu tiên thấp nhất)

**Quy trình bắt buộc trước khi xuất Tags (không được bỏ qua):**

1. Soạn danh sách tag nội dung theo đúng thứ tự ưu tiên ở trên (khởi điểm
   15–25 tags).
2. Nối toàn bộ chuỗi (17 tag cố định + tags nội dung) bằng `", "` thành một
   chuỗi duy nhất.
3. Đếm tổng số ký tự thực tế của chuỗi đó (không ước lượng).
4. Nếu tổng **> 480 ký tự** → cắt dần tag từ **cuối danh sách nội dung**
   (ưu tiên thấp nhất trước) cho đến khi tổng **≤ 480**. KHÔNG BAO GIỜ cắt
   bộ 17 tag cố định hoặc keyword hạt nhân.
5. Luôn ghi rõ tổng số ký tự cuối cùng ngay dưới khối tags khi xuất ra, ví
   dụ: `(Tổng: 477/500 ký tự)`.

---

## BƯỚC 3 — Thumbnail: chọn nội dung cho 3 ô (Visual Strategy)

### Format cố định của kênh (template Canva `DAHVNt9L56k`)

Thumbnail 1920×1080, gồm **3 ô ảnh** trên template có sẵn:

| Ô | Vị trí trong template | Nội dung |
|---|---|---|
| **TRÁI** | `left≈0`, rộng ≈1120 | **Joe Rogan**: khung hình cắt từ chính video, biểu cảm khớp vibe |
| **PHẢI** | `left≈950`, rộng ≈970 | **Khách mời**: khung hình cắt từ chính video, biểu cảm khớp vibe |
| **GIỮA** | ≈624×913 (dọc ~2:3), **viền xanh `#00bf63` 12px** | **Ảnh nội dung**: chính keyword hạt nhân |

Logo 4K góc phải trên và nền giữ nguyên, **không động vào**.

### A. Ô GIỮA — ảnh nội dung

> ⚠️ Ô giữa **KHÔNG BAO GIỜ** là Joe Rogan hay khách mời, vì hai người đã có ở
> hai bên. Ngoài ra dùng được mọi thứ (người thật, đám đông, vật thể, cảnh
> vật, sinh vật), miễn là khắc họa đúng và chân thực nhất nội dung đoạn.

#### 🔑 QUY TẮC SUBJECT: ô giữa phải là CHÍNH keyword, không phải ẩn dụ của nó

Câu hỏi duy nhất trước khi chọn ảnh:

> **"Người vừa gõ keyword hạt nhân vào ô tìm kiếm, nhìn ô giữa này có thấy
> ĐÚNG THỨ HỌ VỪA GÕ không?"**

| Keyword là | Subject ô giữa | Ví dụ |
|---|---|---|
| **Nhân vật** nổi tiếng toàn cầu | **Dùng thẳng mặt họ.** Ảnh archival/báo chí/tài liệu thật | `hitler` → ảnh tư liệu Hitler · `epstein` → ảnh mugshot/báo chí |
| **Vật thể / địa danh** | Chính vật/nơi đó, ảnh chụp thật | `rừng Amazon` → tán rừng nhìn từ trên · `red dead redemption 2` → cảnh trong game |
| **Hiện tượng** | Biểu hiện VẬT LÝ nhìn thấy được | `coronavirus` → khu điều trị, ảnh hiển vi virion, KHÔNG phải biểu đồ trừu tượng |
| **Sự kiện** | Khoảnh khắc/hiện trường đặc trưng | `operation paperclip` → ảnh tư liệu Wernher von Braun cùng quân đội Mỹ |
| **Sinh vật** | Chính con vật đó, ảnh thật, khoảnh khắc dữ dội nhất | `wolf attack` → sói nhe nanh giữa tuyết (đúng như template mẫu) |
| **Hành vi / nhu cầu** | **Cảnh ĐANG THỰC HIỆN hành vi** + bằng chứng KGC | `workout smarter` → thân hình cơ bắp thật đang tập trong gym thật |
| **Câu hỏi / nỗi lo** | Hình ảnh của TRẠNG THÁI câu hỏi mô tả | `phone spying` → điện thoại sáng trong bóng tối, camera chĩa vào người dùng |

**KGC = trung bình** → ô giữa **bắt buộc** mang bằng chứng uy tín nhìn thấy
được: kết quả thật (cơ bắp, vết thương, thiết bị chuyên dụng), bối cảnh chuyên
môn thật (gym, phòng lab, hiện trường), hoặc dấu hiệu chức danh (đồng phục,
phù hiệu).

#### Nguồn ảnh: ẢNH THẬT là mặc định, AI chỉ là phương án cuối

**Thứ tự ưu tiên, chỉ xuống bậc dưới khi bậc trên thật sự không có:**

1. **Ảnh thật, nguồn tự do bản quyền:** Wikimedia Commons
   (`upload.wikimedia.org`), NASA, NOAA, US DoD/DVIDS, Library of Congress,
   National Archives. Đây là ảnh thật mà kênh dùng an toàn.
2. **Ảnh thật từ báo chí/tư liệu khác:** dùng được khi bậc 1 không có ảnh
   đạt. Ghi rõ nguồn trong output để người dùng tự cân nhắc bản quyền.
3. **AI tạo**, **CHỈ KHI chủ đề không thể có ảnh thật**: Chúa Jesus, thiên
   thần, Nephilim, người ngoài hành tinh, sinh vật thần thoại, cảnh tiền sử
   chưa ai chụp, một vụ việc chỉ có lời kể mà không có ảnh. **Cấm** dùng AI
   chỉ vì lười tìm, hoặc vì ảnh thật "trông không đủ đẹp".

**Cách tìm ảnh thật:** WebSearch `"<keyword>" photo` hoặc
`site:commons.wikimedia.org <keyword>`. Mở trang file để lấy **URL ảnh gốc
trực tiếp** (đuôi `.jpg`/`.png`), không lấy URL trang HTML. Ưu tiên ảnh:
- **dọc hoặc có subject ở giữa**, vì ô giữa là khung dọc ~2:3;
- độ phân giải ≥ 800px cạnh ngắn;
- subject rõ, tương phản mạnh, không chữ/watermark đè lên.

**Nếu phải dùng AI** (Canva `generate-image`, `aspectRatio: PORTRAIT_2_3`),
prompt bằng tiếng Anh, ngắn gọn:

```
[Subject: keyword hạt nhân NGUYÊN VĂN + mô tả cụ thể], [bối cảnh thật],
[cảm xúc]. Hyper-realistic raw documentary photo, harsh practical light,
deep shadows, visible texture. No text, no logo, no CGI look, no glossy
glamour lighting. NOT Joe Rogan. NOT a podcast guest.
```

#### TEST CHE TITLE (gate cuối cho ô giữa, không được bỏ qua kể cả ở lượt sửa)

> *"Che title đi, chỉ đưa thumbnail cho một người lạ. Họ có đoán được keyword
> hạt nhân không?"* Không đoán được → đổi ảnh ô giữa.

### B. Ô TRÁI / PHẢI: biểu cảm Joe và khách mời

Ảnh hai bên **phải là khung hình cắt từ chính video của đoạn highlight** (không
dùng ảnh mạng), chọn khung có **biểu cảm khớp với vibe ở Bước 1**:

| Vibe | Joe Rogan (trái) | Khách mời (phải) |
|---|---|---|
| `Funniest` | Cười lớn, há miệng, mắt nheo | Cười / đang kể với vẻ tinh quái |
| `Most Mind-Blowing` | Mắt mở to, miệng hé "whoa", nhíu mày kinh ngạc | Đang giải thích, ánh mắt chắc chắn, tay đang diễn tả |
| `Scariest` | Nghiêm mặt, cau mày, nghiêng người về phía trước | Trầm, nghiêm trọng, ánh mắt ám ảnh |
| `Most Controversial` | Hoài nghi: nhướn mày, nheo mắt, chỉ tay | Quả quyết, nói với cường độ cao |

**Loại ngay** khung: mắt đang chớp/nhắm, miệng đang nhai/uống, mặt bị micro
che quá nửa, nhòe chuyển động, mặt quá nhỏ (wide shot), có caption/lower-third
đè lên mặt, hoặc khung chia đôi màn hình.

> ⚠️ Không nhầm người: Joe là người đầu trọc. Mỗi ô chỉ được có **một người**.
> Nếu khung có cả hai người, chọn khung khác.

**Hướng mặt:** cả hai nên nhìn **về phía ô giữa** (Joe nhìn sang phải, khách
nhìn sang trái). Nếu khung đẹp nhất lại nhìn ra ngoài, lật ngang ảnh
(`flip_media`), **nhưng chỉ khi trong khung không có chữ đọc được** (biển neon
JRE, chữ trên áo), vì lật sẽ làm chữ ngược.

**Output Bước 3** (Tiếng Việt, ngắn): subject ô giữa + nguồn ảnh (link hoặc
"AI vì …") · mốc thời gian khung Joe + biểu cảm · mốc thời gian khung khách +
biểu cảm.

---

## BƯỚC 4 — Dựng thumbnail: MOCK trước → người dùng DUYỆT → mới lưu Canva

> Bước này **tạo thumbnail thật**, không xuất prompt. Chia **hai pha**:
> - **4A. Dựng plan + mock trên máy, không đụng Canva:** chọn khung, ảnh giữa,
>   tính crop, dựng `mock.jpg` 1920×1080, tự soát, rồi **đưa người dùng xem**.
> - **4B. Áp lên Canva, chỉ sau khi người dùng duyệt** ("OK", "lưu đi", hoặc
>   nút **Duyệt thumbnail** trên JRE Studio): copy template, upload, fill,
>   crop đúng plan, commit, export, check back.
>
> Chưa có lời duyệt thì **không** gọi bất kỳ công cụ Canva nào có ghi. Người
> dùng muốn sửa → sửa plan và dựng lại mock (vẫn ở 4A).
> Công cụ: script `E:\Tool\jre-thumb\frames.py` (đọc docstring đầu file),
> Canva connector chỉ dùng ở 4B.

Mọi file của một đoạn nằm trong **một thư mục làm việc** (vd
`<thư mục clip>\thumb_<rank>`): `sheet_*.jpg`, `frame_*.png`, ảnh giữa,
`thumb_plan.json`, `mock.jpg`. File thumbnail cuối:
`<thư mục clip>\thumb_<episode_id>_<rank>_<keyword-slug>.jpg`.
Trên JRE Studio, các đường dẫn này được đưa sẵn trong prompt, dùng đúng y vậy.

### 4A.1 Lấy video của đoạn

Cần file video **của đoạn highlight** (clip đã cắt, hoặc tập gốc + `start`/`end`
từ cutlist). Chưa có đường dẫn video → **hỏi người dùng đúng 1 lần**
(chế độ tự động: ghi ⚠️ rồi bỏ phần khung Joe/khách).
Tập gốc → giới hạn `--start/--end` theo `segments[].start/end`, không quét cả tập.

### 4A.2 Chọn khung Joe & khách

```bash
py -3.14 -X utf8 E:\Tool\jre-thumb\frames.py sheet "<video>" --start <S> --end <E> --step 1.5 --out "<thư mục làm việc>"
```

Script tạo `sheet_XX.jpg` (lưới 5×4, mỗi ô có nhãn **giây của video nguồn**).
**Đọc (Read) TỪNG sheet**, chọn 1 mốc cho Joe và 1 mốc cho khách theo bảng
biểu cảm ở Bước 3B. Đoạn dài > 10 phút thì tăng `--step` lên 3–8 cho đỡ sheet,
rồi quét mịn lại (`--step 1`, hoặc 0.5) quanh vài giây của khung ứng viên để
lấy khoảnh khắc biểu cảm đỉnh nhất.

Cắt khung full-res (kèm bản `_grid.jpg` có lưới tọa độ 100px để đọc hộp đầu)
rồi **Read lại ảnh** để chắc chắn đúng người, đúng biểu cảm:

```bash
py -3.14 -X utf8 E:\Tool\jre-thumb\frames.py grab "<video>" --t <giây_joe> --t <giây_khách> --out "<thư mục làm việc>"
```

### 4A.3 Ảnh ô giữa

- **Ảnh thật (mặc định):** tải về thư mục làm việc. **Wikimedia chặn Canva
  fetch**, nên luôn tải về máy, bắt buộc kèm User-Agent:
  ```bash
  curl -s -L -A "jre-thumb/1.0 (personal thumbnail tool)" -o "<thư mục làm việc>\center_<keyword>.jpg" "<URL ảnh gốc>"
  ```
  Tìm ảnh Commons nhanh qua API (trả tên file, kích thước, license, mô tả):
  `https://commons.wikimedia.org/w/api.php?action=query&list=search&srsearch=<keyword>&srnamespace=6&srlimit=30&format=json`,
  rồi `prop=imageinfo&iiprop=url|size|extmetadata&iiurlwidth=500` để lấy URL
  gốc + thumb. Ghép thumb các ứng viên thành 1 dải và Read để chọn bằng mắt.
- **AI (chỉ khi chủ đề không thể có ảnh thật):** chưa tạo ở 4A. Ghi prompt
  vào plan dưới khóa `"center_ai_prompt"` (mock sẽ hiện ô giữa xám kèm prompt),
  ảnh được tạo bằng Canva `generate-image` ở 4B.

### 4A.4 Plan: crop trọn đầu + fill ảnh giữa

**CROP MẶT, BẮT BUỘC, KHÔNG ĐƯỢC BỎ.** Nếu để Canva tự đặt ảnh, mặt người
trong frame JRE (thường nằm giữa frame) **luôn bị ô giữa che mất**. Lần test
đầu (JRE #2567) mặt Joe bị che nửa vì chỉ căn tâm mặt mà không kiểm cả khối đầu.

1. Mở `frame_<t>_grid.jpg`, đọc **hộp đầu** `X1,Y1,X2,Y2` theo px frame gốc:
   **trọn khối đầu**, từ đỉnh đầu/tóc đến cằm, từ tai trái đến tai phải (gồm
   cả tóc xõa).
2. Ghi vào plan (vị trí các ô của template `DAHVNt9L56k` đã có sẵn trong script):
   ```bash
   py -3.14 -X utf8 E:\Tool\jre-thumb\frames.py crop --side left  --head X1,Y1,X2,Y2 --img "<frame_joe.png>"   --plan "<thư mục làm việc>\thumb_plan.json"
   py -3.14 -X utf8 E:\Tool\jre-thumb\frames.py crop --side right --head X1,Y1,X2,Y2 --img "<frame_khach.png>" --plan "<thư mục làm việc>\thumb_plan.json"
   py -3.14 -X utf8 E:\Tool\jre-thumb\frames.py fill --img "<center.jpg>" --plan "<thư mục làm việc>\thumb_plan.json" [--focus FX,FY] [--zoom 1.2]
   ```
   `crop` đặt **trọn khối đầu** vào giữa dải ô bên còn lộ ra, chừa 15px
   (`--margin`), đỉnh đầu ở y≈40 (`--head-top`), đầu cao ~700px (`--head-h`;
   tự thu nhỏ nếu dải lộ quá hẹp). Dòng `CHECK` in vị trí đầu + khoảng cách
   tới ô giữa. **`OVERLAP` (exit code 2) → plan không được ghi**; giảm
   `--head-h` hoặc chọn khung khác.
   `fill` phủ kín ô giữa; `--focus` là điểm của ảnh (tỉ lệ 0–1) cần nằm giữa
   ô, `--zoom` > 1 để cận hơn.

   **Tỉ lệ chuẩn, lấy từ thumb mẫu người dùng đã duyệt (Joe + khách tóc xoăn
   đeo bandana, ô giữa con sói):** đầu hai bên **to, gần lấp kín dải lộ**,
   đỉnh đầu gần sát mép trên trang, mặt chiếm khoảng nửa trên khung hình, cân
   với ô giữa. Đầu 600px / đỉnh y≈120 đã bị người dùng chê là "nhỏ, không cân
   với ảnh giữa". **Không** thu nhỏ đầu cho "thoáng".
3. **Hai bên phải cân nhau:** dùng cùng `--head-h` cho Joe và khách. Nếu một
   bên bị thu nhỏ vì dải hẹp, chạy lại bên kia với `--head-h` bằng chiều cao
   CHECK của bên nhỏ.
4. Mặt nhìn ra ngoài → chọn khung khác (frame Joe luôn có biển neon JRE, lật
   ảnh sẽ làm chữ ngược, nên **không lật Joe**).

### 4A.5 Mock + tự soát. BẮT BUỘC TRƯỚC KHI ĐƯA NGƯỜI DÙNG XEM

```bash
py -3.14 -X utf8 E:\Tool\jre-thumb\frames.py mock --plan "<thư mục làm việc>\thumb_plan.json" --out "<thư mục làm việc>\mock.jpg"
```

**Read `mock.jpg`** (1920×1080, đã vẽ khung xanh + logo 4K) và soát từng mục,
trượt mục nào là sửa plan rồi dựng lại. **Không** kết luận từ ảnh nhỏ (lần test
đầu đã kết luận "ổn" sai từ preview 600px của Canva).
- [ ] Mặt Joe **trọn vẹn**: mắt, mũi, cả hai tai, không mép nào chạm/khuất
  sau ô giữa.
- [ ] Mặt khách trọn vẹn, tương tự.
- [ ] Hai đầu **cao xấp xỉ nhau** (chênh ≤ 10%) và **ngang hàng** (đỉnh đầu
  lệch ≤ 60px).
- [ ] Đầu **to ngang thumb mẫu** (≈700px, gần lấp kín dải lộ), không nhỏ lọt
  thỏm giữa nền.
- [ ] Không đầu nào bị cắt đỉnh ở mép trên trang; logo 4K được phép đè
  tóc/nền, **không được đè mặt**.
- [ ] Biểu cảm vẫn đọc được ở cỡ nhỏ: thu nhỏ mock còn 320px rồi nhìn lại.
- [ ] Subject ô giữa nằm giữa khung, nhận ra ngay keyword.

**Đưa người dùng xem mock** (gửi file / trên Studio thì hiện sẵn), ghi rõ đã
kiểm những gì và còn hạn chế gì (vd micro che miệng do khung gốc). **Dừng ở
đây chờ duyệt.**

### 4B. Áp lên Canva. CHỈ SAU KHI NGƯỜI DÙNG DUYỆT

1. `copy-design` từ template **`DAHVNt9L56k`**. **Không bao giờ sửa trực
   tiếp template gốc.** `update_title` cho bản copy:
   `THUMB | <keyword hạt nhân> | <Khách mời>`.
2. Upload từng ảnh trong plan: `create-upload-url` (mỗi URL dùng một lần) rồi
   ```bash
   curl -s -X POST "<upload_url>" -H "Content-Type: application/octet-stream" --data-binary "@<file>"
   ```
   lấy `mediaId`. Plan có `center_ai_prompt` → `generate-image`
   (`PORTRAIT_2_3`) với đúng prompt đó, dùng `media_id` của kết quả.
3. `read-design` bản copy với `open_transaction: true`, fields
   `design_content` + `thumbnails`. **Nhận diện 3 ô theo hình học, không
   hardcode locator id:** ô viền xanh `#00bf63` → **GIỮA**; ô ảnh lớn `left`
   ≈ 0, rộng > 900, không phải nền 1920×1080 → **TRÁI (Joe)**; ô ảnh lớn
   `left` ≈ 900–1000 → **PHẢI (khách)**; nền, logo 4K, nét gạch đỏ → giữ
   nguyên. Đối chiếu element với `element` trong plan; lệch (template đã bị
   sửa) → dừng, báo người dùng.
4. `edit-design` (`keep_open`): 3 lệnh `update_fill` (alt_text tiếng Anh) rồi
   `crop_media` mỗi ô đúng `image_box` trong plan (ô giữa AI: tải ảnh kết quả
   về rồi chạy `fill` để tính, hoặc để Canva tự fill).
   **Logo 4K của kênh** (`E:\Tool\jre-thumb\logo_4k.png`, ghi sẵn trong
   `plan.logo`): upload như các ảnh khác, `update_fill` vào badge 4K của
   template (ô nhỏ góc phải trên, `left` ≈ 1772), rồi `resize_element`
   (`preserve_aspect_ratio: false`) + `position_element` đúng
   `plan.logo.element` (140×109 tại 1746,29; logo ngang hơn badge cũ nên ô
   phải rộng ra, không để Canva cắt hai bên logo). Mock đã vẽ sẵn logo này.
5. So thumbnail trả về với mock đã duyệt. Khớp → `edit-design`
   `finalize: commit`. Không khớp → sửa tiếp trong transaction, **không
   commit bản khác mock**.
6. `export-design`: `jpg`, `quality` 90, `width` 1920, `height` 1080, tải về:
   ```bash
   curl -s -L -o "<file thumbnail cuối>" "<download_url>"
   ```
   YouTube giới hạn **2 MB**: file > 2 MB → export lại với `quality` 80.
7. **CHECK BACK SẢN PHẨM CUỐI. BẮT BUỘC MỖI LẦN EXPORT, KỂ CẢ LƯỢT SỬA LẠI.**
   Người dùng yêu cầu rõ: *mỗi lần chạy phải tự kiểm lại khuôn mặt Joe và
   khách có đúng vị trí và tỷ lệ không*. Không được báo "xong" khi chưa qua
   bước này.
   1. So file export với `mock.jpg` đã duyệt:
      ```bash
      py -3.14 -X utf8 E:\Tool\jre-thumb\frames.py verify --export "<file thumbnail cuối>" --mock "<thư mục làm việc>\mock.jpg"
      ```
      Hai dải bên phải `OK` (lệch trung bình ≤ 10; bản đúng thường 1–2).
      `MISMATCH` → Canva đặt ảnh khác bản đã duyệt (thường do quên `commit`,
      commit nhầm transaction, hoặc export trước khi lưu) → sửa rồi export
      lại, không giao file.
   2. **Read file export** (không phải mock) và soát lại checklist ở 4A.5.
   3. Báo kết quả thành một dòng cụ thể, vd:
      `Check back: Joe OK (diff 1.8) · khách OK (diff 1.2) · 2 đầu ~700px,
      cách ô giữa 86px / 19px · logo không đè mặt`.

**Output Bước 4:** 4A → đường dẫn `mock.jpg` + bảng nguồn 3 ô (Joe @ giây X ·
khách @ giây Y · ô giữa: nguồn/license hoặc AI) + kết quả tự soát, rồi chờ
duyệt. 4B → file thumbnail + link edit Canva + dòng **Check back**.

---

## CONSTRAINTS CHUNG

| Yếu tố | Quy tắc |
|--------|---------|
| **🔑 Keyword hạt nhân** | Cụm khán giả GÕ VÀO Ô TÌM KIẾM. Không giới hạn loại từ — `workout smarter` hợp lệ y hệt `hitler`. Lấy từ `core_keyword` của cutlist V2.4+ nếu có; **không tự đổi**. Cấm dùng tên khách mời làm keyword, trừ khi chính khách là thứ người ta săn tìm |
| **Keyword trong title** | **Nguyên văn**, nằm trong **5 từ đầu**. `Joe Rogan` KHÔNG được chiếm 2 từ đầu (dữ liệu kênh: mở đầu bằng "Joe Rogan" = Idx 1.00, trung tính) nhưng vẫn bắt buộc có trong title (bỏ hẳn = Idx 0.88). Độ dài 9–14 từ |
| **Keyword trong thumbnail** | Ô giữa phải là **CHÍNH keyword**, không phải ẩn dụ của nó. Test: *"người vừa gõ cụm đó, nhìn có thấy đúng thứ họ gõ không?"* Gate cuối: **test che title** |
| **Format thumbnail** | Copy template Canva `DAHVNt9L56k` (không sửa bản gốc). TRÁI = Joe, PHẢI = khách: khung cắt từ chính video, biểu cảm khớp vibe, nhìn về phía ô giữa. GIỮA = ảnh nội dung, viền xanh. Plan + mock 1920px trên máy (không Canva) → người dùng duyệt → mới copy/fill/crop/commit trên Canva → export JPG ≤ 2 MB |
| **Nguồn ảnh ô giữa** | Ảnh THẬT là mặc định (ưu tiên Wikimedia/NASA/DoD/Archives, rồi đến báo chí, ghi nguồn). AI (`generate-image`) **chỉ** khi chủ đề không thể có ảnh thật (Jesus, thiên thần, alien, sinh vật thần thoại…) |
| **Reach × KGC** | `R1` → title bắt buộc có cầu nối sang cụm R3. `KGC = medium` → credential phải nằm trong title (Format 1C) VÀ bằng chứng uy tín phải nhìn thấy được trong thumbnail. `KGC = low` → dừng, báo người dùng |
| **Tín hiệu "Story"** | Khối là câu chuyện có thật (nhân vật + mốc thời gian + diễn biến + kết cục) → cân nhắc đưa `Story`/`Stories` vào title. Dữ liệu kênh: Idx 1.50, CI [1.10–1.90] |
| Ngôn ngữ output | Title, Description, Tags, prompt AI (nếu có) → Tiếng Anh. Phân tích → Tiếng Việt |
| **Cutlist** | Nếu người dùng cung cấp cutlist từ `chon-noi-dung-jre` / `-v2` → BẮT BUỘC nạp ở Bước 0 và tái sử dụng `hook_en`, `topics`, `summary_en`, `start` (và `value_axis`, `gtf`, `fit_reason`, `guest_profile` nếu là cutlist V2). Verify chéo với transcript; mâu thuẫn → báo người dùng, không tự chữa |
| **Chọn subject** | Tách bạch celebrity factor (quyết định tên có đứng trước không) với thẩm quyền/`gtf` (quyết định có nhấn "chính người này" không). Thẩm quyền cao + tên vô danh → dùng Format 1C danh xưng. `value_axis = persona` → bắt buộc guest-forward |
| **Gate thẩm quyền** | Title không được hứa hẹn nội dung nằm trong `guest_profile.low_authority_zones` — kể cả khi chủ đề đó rất hot với kênh |
| **Chính tả tên riêng** | CẤM copy tên riêng theo cách transcript viết. Luôn dùng chính tả chuẩn; không chắc → tra web trước khi đưa vào title/tags. Biến thể gõ sai phổ biến → cho vào TAGS, không cho vào title |
| **Đuôi title (quan trọng, hay bị mất ở lượt sửa lại)** | Format 1 content-forward LUÔN kết `\| Joe Rogan & [Tên Khách Mời]` — không có phiên bản rút gọn. Verify lại đuôi từng title trước khi xuất, kể cả khi lượt này chỉ yêu cầu đổi keyword/SEO chứ không nhắc gì đến format |
| Subject ô giữa | Nếu title hook là nhân vật lịch sử nổi tiếng → DÙNG ẢNH THẬT MẶT HỌ NGAY. Ô giữa không bao giờ là Joe hay khách (hai người đã ở hai bên) |
| SEO | **Keyword hạt nhân nguyên văn** xuất hiện tự nhiên 3–4 lần trong Description, trong đó **1 lần ở câu đầu tiên** |
| Titles | Dưới 100 ký tự. `Joe Rogan` bắt buộc. XUẤT CẢ 2 FORMAT: Format 1 (trực diện) + Format 2 (câu hỏi gợi mở) thành 2 bảng riêng, mỗi bảng 3 title. Format 1C là biến thể của Format 1, dùng thay thế khi cây quyết định chỉ vào nó. Cả hai đều áp quy tắc ai nổi hơn đứng trước |
| Số liệu trong title | Ưu tiên đóng khung subject bằng CON SỐ CỤ THỂ (tuổi, chiều cao, khoảng cách, năm...) để tăng độ thật & CTR. CHỈ dùng số có thật trong transcript, gán đúng đối tượng. CẤM bịa, làm tròn kịch tính, hay lấy số từ tên file nếu không được nói trong nội dung. Không xác thực được → không dùng |
| Description | Dòng đầu = tên tập JRE (nếu có). Dòng cuối = `⏱ TIMESTAMPS BELOW` |
| Timestamps | Tính từ ĐẦU CLIP, mốc đầu luôn `0:00` (hoặc gần đó nếu clip tự nhiên bắt đầu vài giây sau 0). Transcript nguyên tập → BẮT BUỘC trừ offset `start` từ cutlist hoặc từ header "Thời gian: X → Y". Không xác định được `start` → hỏi 1 lần, không đoán, không xuất timestamp gốc của tập. **Mốc cuối cùng phải phủ ≥85% tổng thời lượng clip** — verify bằng % phủ trước khi xuất, không dừng sớm chỉ vì phần đầu có nhiều hook hơn |
| Tags | 17 tags cố định đứng đầu, sau đó tags nội dung xếp theo ưu tiên giảm dần, Keyword hạt nhân luôn đứng đầu danh sách nội dung. Tổng toàn bộ chuỗi tags ≤480 ký tự (ngưỡng an toàn — giới hạn cứng YouTube là 500). Luôn đếm ký tự thực tế và cắt từ cuối danh sách nội dung nếu vượt |
| Image style | Raw, gritty, documentary — không bao giờ glossy hay staged |

---

## VÍ DỤ ẢNH Ô GIỮA (để tham khảo)

Từ transcript về Einstein / lý thuyết bị chôn vùi:
- ✅ Ảnh archival Einstein mặt thật (Wikimedia, public domain) — **ảnh thật**
- ✅ Ảnh thật trang bản thảo viết tay chi chít phương trình của Einstein — **ảnh thật**
- ❌ Bảng đen phương trình chung chung không có mặt người (quá abstract, CTR thấp)

Từ transcript về Satan/Jesus/Bishop:
- ✅ Chúa Jesus / Satan → không có ảnh thật → **AI** (`generate-image`), dạng ảnh tài liệu thô, không tranh vẽ
- ✅ Giám mục / nhà thờ có thật được nhắc tên → **ảnh báo chí thật**
- ❌ Joe Rogan hoặc khách mời ở ô giữa (CẤM, họ đã ở hai bên)
- ❌ Studio JRE (tránh, quá generic)

Từ transcript về cấu trúc / công trình bí ẩn ẩn dưới lòng đất (kim tự tháp,
hầm ngầm, thành phố cổ chìm...):
- ✅ Hố khai quật khổng lồ mở giữa hiện trường, đèn pha ban đêm rọi xuống lộ
  ra hàng cột đá/cấu trúc khổng lồ chìm dần vào bóng tối, có bóng người ẩn
  danh đứng mép hố để tạo tỷ lệ so sánh. Có ảnh khai quật thật → dùng ảnh thật;
  cấu trúc chỉ là giả thuyết, chưa ai chụp → **AI**
- ❌ Ảnh archival ghim cạnh bản in radar/tài liệu trên corkboard kiểu hồ sơ
  điều tra (đã test — CTR thấp, tránh dùng)

---

## PHỤ LỤC — CƠ SỞ DỮ LIỆU CỦA CÁC LUẬT V1.1

Đo trên **1.549 video ≥4 năm tuổi** của kênh JRE Clips (mẫu 1.725 video, toàn
bộ video >880K view, quét 8/2026). `Idx` = median view của nhóm ÷ median toàn
mẫu. `CI95` chứa 1.00 nghĩa là **chưa đủ bằng chứng**.

| Luật trong skill | Cơ sở | Idx | CI95 | Độ chắc |
|---|---|---|---|---|
| Cân nhắc đưa `Story`/`Stories` vào title | Title chứa "Story/Stories" (3,3% sản lượng) | **1.50** | [1.10–1.90] | ✅ Vững |
| Giữ tên Joe nhưng đừng để chiếm 2 từ đầu | Mở đầu bằng "Joe Rogan" (52,8% sản lượng) | 1.00 | — | ⚪ Trung tính |
| — nhưng đừng bỏ hẳn tên Joe | Title không có chữ Joe/Rogan (19,2%) | 0.88 | [0.80–1.00] | ⚠️ Sát ngưỡng |
| Title 9–14 từ | 9–11 từ / 12–14 từ | 1.05 / 1.08 | — | ⚠️ Chênh nhỏ |
| — tránh title ≥15 từ | ≥15 từ (3,7%) | 0.83 | — | ⚠️ |
| Thang Reach (R3 > R1) | Ca đối chứng NdGT tập #919: cùng khách, cùng ngày, chênh 54 lần view | — | n=5 | ⚠️ **Giả thuyết làm việc** |

### ⚠️ Một luật hiện có của skill đang mâu thuẫn với dữ liệu — cần người dùng quyết

Luật *"Format 1 content-forward LUÔN kết `| Joe Rogan & [Tên Khách Mời]`"*.

Dữ liệu kênh: title chứa `w/` hoặc `|` (28,0% sản lượng) có **Idx 0.90, CI
[0.85–1.00]** — sát ngưỡng, hướng tiêu cực. Không đủ mạnh để bác bỏ, nhưng đủ
để đáng nghi. Giả thuyết: cái đuôi đó ăn mất ký tự của phần hứa hẹn nội dung.

**Chưa đổi luật** vì đây là quy ước thương hiệu của kênh, không phải chỗ để
skill tự ý sửa. **Cách kiểm chứng rẻ:** trong 20 clip tới, cho 10 clip giữ
nguyên đuôi `| Joe Rogan & [Khách]`, 10 clip đưa tên khách vào giữa câu gắn
với hành động (*"Green Beret Justin Lascek Leaves Joe Speechless"*). Sau 60
ngày so median view. Nếu nhóm hai thắng rõ → sửa luật.

### Nhắc lại một sai lầm đã mắc, để không lặp

Có một phép đo sớm hơn *"có vẻ"* chứng minh rằng title chứa thực thể đích danh
thì ăn hơn (73% vs 49%, p<0.001). Đó là **artifact**: từ điển thực thể được
soạn bằng cách đọc chính nhóm video top, nên nó tự khớp với đáp án. Đo lại
bằng NER không thiên vị thì hiệu ứng biến mất hoàn toàn (chi2=1,6, ns).

Bài học cho skill này: **keyword không cần là "tên riêng" mới có giá trị.**
`workout smarter` (15M), `phone spying` (19M), `why you can't lose weight`
(11M) đều không phải thực thể đích danh — chúng chỉ cần là thứ có người gõ.
Đó chính là lý do V1.1 định nghĩa keyword theo **hành vi tìm kiếm**, không theo
loại từ.
